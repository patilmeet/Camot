package com.remotecam.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.remotecam.app.R
import com.remotecam.app.databinding.ActivityMainBinding
import com.remotecam.app.service.RemoteCamService
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("remotecam", Context.MODE_PRIVATE) }
    private var statusListener: ListenerRegistration? = null
    private val logLines = mutableListOf<String>()

    // ── Permission launcher ──
    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            appendLog("✓ All permissions granted")
            startService()
        } else {
            appendLog("✗ Some permissions denied — service may not work fully")
            Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
        }
    }

    // ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSavedConfig()
        setupClickListeners()
        appendLog("RemoteCam ready. Configure Firebase and tap START.")
    }

    override fun onDestroy() {
        super.onDestroy()
        statusListener?.remove()
    }

    // ─────────────────────────────────────────────────────────────
    // UI setup
    // ─────────────────────────────────────────────────────────────

    private fun setupClickListeners() {
        // Start / Stop service
        binding.btnStart.setOnClickListener {
            saveConfig()
            checkPermissionsAndStart()
        }

        binding.btnStop.setOnClickListener {
            RemoteCamService.stop(this)
            setServiceState(running = false)
            appendLog("Service stopped.")
            statusListener?.remove()
        }

        // Save config
        binding.btnSave.setOnClickListener {
            saveConfig()
            Toast.makeText(this, "Config saved", Toast.LENGTH_SHORT).show()
            appendLog("Config saved.")
        }

        // Auto-start toggle
        binding.switchAutoStart.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("auto_start", checked).apply()
            appendLog(if (checked) "Auto-start on boot: ON" else "Auto-start on boot: OFF")
        }

        // Test ping button
        binding.btnPing.setOnClickListener {
            sendTestCommand("PING", emptyMap())
        }

        // Test capture buttons
        binding.btnCaptureBack.setOnClickListener {
            sendTestCommand("CAPTURE_CAMERA", mapOf("camera" to "back"))
        }
        binding.btnCaptureFront.setOnClickListener {
            sendTestCommand("CAPTURE_CAMERA", mapOf("camera" to "front"))
        }

        // Clear log
        binding.btnClearLog.setOnClickListener {
            logLines.clear()
            binding.tvLog.text = ""
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Config persistence
    // ─────────────────────────────────────────────────────────────

    private fun saveConfig() {
        prefs.edit()
            .putString("collection", binding.etCollection.text.toString().ifBlank { "commands" })
            .apply()
        appendLog("Collection path: ${binding.etCollection.text.toString().ifBlank { "commands" }}")
    }

    private fun loadSavedConfig() {
        binding.etCollection.setText(prefs.getString("collection", "commands"))
        binding.switchAutoStart.isChecked = prefs.getBoolean("auto_start", false)
    }

    // ─────────────────────────────────────────────────────────────
    // Permissions
    // ─────────────────────────────────────────────────────────────

    private fun checkPermissionsAndStart() {
        val needed = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            startService()
        } else {
            permLauncher.launch(missing.toTypedArray())
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Service control
    // ─────────────────────────────────────────────────────────────

    private fun startService() {
        RemoteCamService.start(this)
        setServiceState(running = true)
        appendLog("Service started — listening for commands...")
        startListeningForResponses()
    }

    private fun setServiceState(running: Boolean) {
        binding.btnStart.isEnabled = !running
        binding.btnStop.isEnabled  = running
        binding.btnPing.isEnabled  = running
        binding.btnCaptureBack.isEnabled  = running
        binding.btnCaptureFront.isEnabled = running

        binding.statusIndicator.setBackgroundResource(
            if (running) R.drawable.led_green else R.drawable.led_red
        )
        binding.tvServiceStatus.text = if (running) "SERVICE RUNNING" else "SERVICE STOPPED"
    }

    // ─────────────────────────────────────────────────────────────
    // Listen for responses to display in UI
    // ─────────────────────────────────────────────────────────────

    private fun startListeningForResponses() {
        val collection = prefs.getString("collection", "commands") ?: "commands"
        val db: FirebaseFirestore = Firebase.firestore

        statusListener?.remove()
        statusListener = db.collection(collection)
            .document("__response__")
            .addSnapshotListener { snap, err ->
                if (err != null) { appendLog("⚠ Firestore error: ${err.message}"); return@addSnapshotListener }
                if (snap == null || !snap.exists()) return@addSnapshotListener

                val cmd    = snap.getString("command") ?: "?"
                val status = snap.getString("status") ?: "?"
                val imgUrl = snap.getString("imageUrl")

                if (imgUrl != null && cmd == "CAPTURE_CAMERA") {
                    appendLog("📸 Photo received! URL:\n$imgUrl")
                    binding.tvLastImageUrl.text = imgUrl
                    binding.tvLastImageUrl.visibility = View.VISIBLE
                } else {
                    appendLog("↩ Response [$cmd]: $status")
                }
            }
    }

    // ─────────────────────────────────────────────────────────────
    // Test commands — write directly to Firestore from the app
    // ─────────────────────────────────────────────────────────────

    private fun sendTestCommand(command: String, payload: Map<String, Any>) {
        val collection = prefs.getString("collection", "commands") ?: "commands"
        val db: FirebaseFirestore = Firebase.firestore

        db.collection(collection).document("__active__").set(
            mapOf(
                "command"   to command,
                "payload"   to payload,
                "timestamp" to com.google.firebase.firestore.FieldValue.serverTimestamp(),
                "sentFrom"  to "remotecam-ui"   // different from service's "remotecam-android"
            )
        ).addOnSuccessListener {
            appendLog("→ Sent command: $command")
        }.addOnFailureListener { e ->
            appendLog("✗ Failed to send: ${e.message}")
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Log helper
    // ─────────────────────────────────────────────────────────────

    private fun appendLog(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logLines.add("[$time] $msg")
        // Keep last 100 lines
        if (logLines.size > 100) logLines.removeAt(0)
        runOnUiThread {
            binding.tvLog.text = logLines.joinToString("\n")
            binding.scrollLog.post { binding.scrollLog.fullScroll(View.FOCUS_DOWN) }
        }
    }
}
