package com.remotecam.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * BootReceiver
 *
 * Fired by Android after the device reboots.
 * Automatically restarts RemoteCamService so commands keep working
 * even after a phone restart — no manual action needed.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            Log.i("BootReceiver", "Boot detected — starting RemoteCamService")

            // Only auto-start if the user had it enabled before reboot
            val prefs = context.getSharedPreferences("remotecam", Context.MODE_PRIVATE)
            val autoStart = prefs.getBoolean("auto_start", false)

            if (autoStart) {
                RemoteCamService.start(context)
            }
        }
    }
}
