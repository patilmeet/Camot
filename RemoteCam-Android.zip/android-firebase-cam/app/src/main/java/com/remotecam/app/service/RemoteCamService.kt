package com.remotecam.app.service

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import com.remotecam.app.R
import com.remotecam.app.RemoteCamApp
import com.remotecam.app.ui.MainActivity
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/**
 * RemoteCamService — Foreground Service
 *
 * Stays alive even when the app is in the background or screen is off.
 * Listens to Firestore for commands and executes them (capture, ping, etc.)
 *
 * KEY POINTS:
 *  - foregroundServiceType="camera" in manifest lets us use camera in background (Android 9+)
 *  - Uses Camera2 API directly (not CameraX) because CameraX requires a lifecycle owner
 *  - Uses HandlerThread for camera operations (camera2 is callback-based)
 *  - Coroutines handle Firebase async operations
 */
class RemoteCamService : Service() {

    companion object {
        private const val TAG = "RemoteCamService"
        const val ACTION_START = "START"
        const val ACTION_STOP  = "STOP"
        const val NOTIFICATION_ID = 1001

        // Call this from Activity or BootReceiver
        fun start(context: Context) {
            val intent = Intent(context, RemoteCamService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, RemoteCamService::class.java).apply { action = ACTION_STOP }
            )
        }
    }

    // ── Firebase ──
    private val db: FirebaseFirestore by lazy { Firebase.firestore }
    private var cmdListener: ListenerRegistration? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ── Camera2 ──
    private var cameraManager: CameraManager? = null
    private var cameraDevice: CameraDevice? = null
    private var imageReader: ImageReader? = null
    private var cameraThread: HandlerThread? = null
    private var cameraHandler: Handler? = null
    private var captureCallback: ((ByteArray) -> Unit)? = null

    // ── State ──
    private var isRunning = false
    private var lastCommandId = ""  // prevents duplicate execution

    // ─────────────────────────────────────────────────────────────
    // Service lifecycle
    // ─────────────────────────────────────────────────────────────

    override fun onBind(intent: Intent?): IBinder? = null   // Not a bound service

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            else -> startForegroundWithNotification()
        }

        if (!isRunning) {
            isRunning = true
            startCameraThread()
            startFirebaseListener()
            Log.i(TAG, "Service started")
        }

        // START_STICKY = system restarts this service if killed
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        cmdListener?.remove()
        serviceScope.cancel()
        closeCameraDevice()
        cameraThread?.quitSafely()
        Log.i(TAG, "Service destroyed")
    }

    // ─────────────────────────────────────────────────────────────
    // Foreground Notification — required to stay alive in background
    // ─────────────────────────────────────────────────────────────

    private fun startForegroundWithNotification() {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, RemoteCamService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, RemoteCamApp.CHANNEL_ID)
            .setContentTitle("RemoteCam Active")
            .setContentText("Listening for remote commands...")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)       // Can't be swiped away
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_delete, "Stop", stopIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    // ─────────────────────────────────────────────────────────────
    // Firebase — listen for commands
    // ─────────────────────────────────────────────────────────────

    private fun startFirebaseListener() {
        val prefs = getSharedPreferences("remotecam", Context.MODE_PRIVATE)
        val collection = prefs.getString("collection", "commands") ?: "commands"

        Log.i(TAG, "Listening to Firestore: $collection/__active__")

        cmdListener = db.collection(collection)
            .document("__active__")
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.e(TAG, "Firestore error: ${err.message}"); return@addSnapshotListener }
                if (snap == null || !snap.exists()) return@addSnapshotListener

                val cmdId  = snap.id + (snap.getLong("timestamp")?.toString() ?: "")
                val cmd    = snap.getString("command") ?: return@addSnapshotListener
                val sender = snap.getString("sentFrom") ?: ""

                // Skip self-sent commands and already-processed commands
                if (sender == "remotecam-android" || cmdId == lastCommandId) return@addSnapshotListener
                lastCommandId = cmdId

                @Suppress("UNCHECKED_CAST")
                val payload = (snap.get("payload") as? Map<String, Any>) ?: emptyMap()

                Log.i(TAG, "Command received: $cmd")
                handleCommand(cmd, payload, collection)
            }
    }

    private fun handleCommand(cmd: String, payload: Map<String, Any>, collection: String) {
        serviceScope.launch {
            when (cmd.uppercase()) {
                "CAPTURE_CAMERA" -> {
                    val camFacing = payload["camera"] as? String ?: "back"
                    captureAndUpload(camFacing, collection)
                }
                "PING" -> {
                    sendResponse(collection, mapOf(
                        "command" to "PING",
                        "status"  to "pong",
                        "device"  to Build.MODEL
                    ))
                }
                "LOG_STATUS" -> {
                    sendResponse(collection, mapOf(
                        "command"     to "LOG_STATUS",
                        "status"      to "ok",
                        "device"      to Build.MODEL,
                        "android"     to Build.VERSION.RELEASE,
                        "serviceRunning" to true
                    ))
                }
                else -> {
                    sendResponse(collection, mapOf(
                        "command" to cmd,
                        "status"  to "acknowledged"
                    ))
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Camera2 — background capture
    // ─────────────────────────────────────────────────────────────

    private fun startCameraThread() {
        cameraThread = HandlerThread("CameraBackground").also { it.start() }
        cameraHandler = Handler(cameraThread!!.looper)
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }

    /**
     * Opens camera, takes a single JPEG shot, closes camera, uploads to Storage.
     * This whole flow runs on the camera background thread.
     */
    private suspend fun captureAndUpload(camFacing: String, collection: String) {
        try {
            Log.i(TAG, "Starting capture ($camFacing camera)...")
            val bytes = captureJpeg(camFacing)
            Log.i(TAG, "Captured ${bytes.size} bytes — uploading...")

            val url = uploadToStorage(bytes)
            Log.i(TAG, "Upload complete: $url")

            sendResponse(collection, mapOf(
                "command"      to "CAPTURE_CAMERA",
                "imageUrl"     to url,
                "camera"       to camFacing,
                "status"       to "ok",
                "deviceModel"  to Build.MODEL,
                "androidVer"   to Build.VERSION.RELEASE,
            ))
        } catch (e: Exception) {
            Log.e(TAG, "Capture failed: ${e.message}")
            sendResponse(collection, mapOf(
                "command" to "CAPTURE_CAMERA",
                "status"  to "error: ${e.message}"
            ))
        }
    }

    /**
     * captureJpeg — suspends until a JPEG frame is captured, then returns the bytes.
     * Uses Camera2 API so it works without a UI or lifecycle owner.
     */
    private suspend fun captureJpeg(camFacing: String): ByteArray =
        suspendCancellableCoroutine { cont ->
            try {
                val lensDir = if (camFacing == "front")
                    CameraCharacteristics.LENS_FACING_FRONT
                else
                    CameraCharacteristics.LENS_FACING_BACK

                // Find the right camera ID
                val cameraId = cameraManager!!.cameraIdList.firstOrNull { id ->
                    val chars = cameraManager!!.getCameraCharacteristics(id)
                    chars.get(CameraCharacteristics.LENS_FACING) == lensDir
                } ?: throw Exception("Camera not found: $camFacing")

                // Set up ImageReader — will receive the JPEG frame
                val reader = ImageReader.newInstance(1280, 960, ImageFormat.JPEG, 1)
                imageReader = reader

                reader.setOnImageAvailableListener({ ir ->
                    val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
                    val buffer: ByteBuffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    image.close()
                    closeCameraDevice()

                    if (cont.isActive) cont.resume(bytes) {}
                }, cameraHandler)

                // Open the camera
                cameraManager!!.openCamera(cameraId, object : CameraDevice.StateCallback() {
                    override fun onOpened(camera: CameraDevice) {
                        cameraDevice = camera
                        // Create a capture session targeting the ImageReader surface
                        val surface = reader.surface
                        camera.createCaptureSession(
                            listOf(surface),
                            object : CameraCaptureSession.StateCallback() {
                                override fun onConfigured(session: CameraCaptureSession) {
                                    val request = camera.createCaptureRequest(
                                        CameraDevice.TEMPLATE_STILL_CAPTURE
                                    ).apply {
                                        addTarget(surface)
                                        // Auto-focus and auto-exposure
                                        set(CaptureRequest.CONTROL_AF_MODE,
                                            CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                        set(CaptureRequest.CONTROL_AE_MODE,
                                            CaptureRequest.CONTROL_AE_MODE_ON)
                                    }.build()

                                    session.capture(request, null, cameraHandler)
                                }
                                override fun onConfigureFailed(session: CameraCaptureSession) {
                                    if (cont.isActive) cont.cancel(Exception("Camera session config failed"))
                                }
                            },
                            cameraHandler
                        )
                    }
                    override fun onDisconnected(camera: CameraDevice) { camera.close() }
                    override fun onError(camera: CameraDevice, error: Int) {
                        camera.close()
                        if (cont.isActive) cont.cancel(Exception("Camera error code: $error"))
                    }
                }, cameraHandler)

            } catch (e: Exception) {
                if (cont.isActive) cont.cancel(e)
            }
        }

    private fun closeCameraDevice() {
        try { cameraDevice?.close() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        cameraDevice = null
        imageReader = null
    }

    // ─────────────────────────────────────────────────────────────
    // Firebase Storage — upload photo
    // ─────────────────────────────────────────────────────────────

    private suspend fun uploadToStorage(bytes: ByteArray): String {
        val storage = Firebase.storage
        val ref = storage.reference.child("captures/${System.currentTimeMillis()}.jpg")

        // uploadBytes is a Task — use await() from kotlinx-coroutines-play-services
        ref.putBytes(bytes).await()
        return ref.downloadUrl.await().toString()
    }

    // ─────────────────────────────────────────────────────────────
    // Firestore — write response
    // ─────────────────────────────────────────────────────────────

    private suspend fun sendResponse(collection: String, data: Map<String, Any>) {
        try {
            val payload = data.toMutableMap().apply {
                put("responseTime", com.google.firebase.firestore.FieldValue.serverTimestamp())
                put("sentFrom", "remotecam-android")
            }
            db.collection(collection).document("__response__")
                .set(payload)
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "sendResponse failed: ${e.message}")
        }
    }

    // Extension to use coroutine await() on Firebase Tasks
    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
        kotlinx.coroutines.tasks.await()
}
