# RemoteCam — Android Background Camera Service

A native Android app that listens to Firebase Firestore for commands
and captures photos **even when the screen is off or app is backgrounded**.

---

## How It Works

```
Your Web Dashboard  ──→  Firestore: commands/__active__
                                         ↓
                              Android Foreground Service
                              (always running, screen can be off)
                                         ↓
                              Camera2 captures JPEG
                                         ↓
                              Firebase Storage upload
                                         ↓
                         Firestore: commands/__response__  ──→  Dashboard shows photo
```

---

## Project Structure

```
app/src/main/
├── AndroidManifest.xml              — permissions + service declaration
├── java/com/remotecam/app/
│   ├── RemoteCamApp.kt              — Application class, notification channel
│   ├── service/
│   │   ├── RemoteCamService.kt      — ★ THE CORE: foreground service + camera2 + firebase
│   │   └── BootReceiver.kt          — auto-restart after device reboot
│   └── ui/
│       └── MainActivity.kt          — control panel UI
└── res/
    └── layout/activity_main.xml     — UI layout
```

---

## Setup (Step by Step)

### Step 1 — Create Firebase Project

1. Go to https://console.firebase.google.com
2. Click **Add project** → name it (e.g. "RemoteCam")
3. Enable **Google Analytics** (optional)

### Step 2 — Enable Firestore

1. In Firebase Console → **Firestore Database** → **Create database**
2. Choose **Start in test mode** (allows read/write without auth — secure later)
3. Select a region → Done

### Step 3 — Enable Firebase Storage

1. Firebase Console → **Storage** → **Get started**
2. Choose **Start in test mode**
3. Select same region as Firestore → Done

### Step 4 — Add Android App to Firebase

1. Firebase Console → Project Overview → **Add app** → Android icon
2. Package name: `com.remotecam.app`
3. App nickname: RemoteCam
4. Click **Register app**
5. **Download `google-services.json`**
6. Place it here:
   ```
   RemoteCam/app/google-services.json   ← REQUIRED, without this the app won't build
   ```

### Step 5 — Open in Android Studio

1. Open Android Studio → **Open** → select the `RemoteCam` folder
2. Wait for Gradle sync to complete
3. Make sure `google-services.json` is in the `app/` folder

### Step 6 — Build & Install

```bash
# From project root:
./gradlew installDebug

# Or just press ▶ Run in Android Studio
```

### Step 7 — Grant Permissions

On first launch the app will request:
- **Camera** — required for photo capture
- **Notifications** — required for the foreground service notification (Android 13+)

Both must be granted.

### Step 8 — Start the Service

1. Open the app
2. Set the **Collection Path** (default: `commands` — must match your dashboard)
3. Tap **▶ START SERVICE**
4. You'll see a persistent notification: *"RemoteCam Active — Listening for remote commands..."*
5. You can now close the app / turn off the screen — **the service keeps running**

---

## Firestore Document Structure

### Command (dashboard → device)
Written to: `commands/__active__`

```json
{
  "command": "CAPTURE_CAMERA",
  "payload": { "camera": "back" },
  "timestamp": <server timestamp>,
  "sentFrom": "web-dashboard",
  "status": "pending"
}
```

### Response (device → dashboard)
Written to: `commands/__response__`

```json
{
  "command": "CAPTURE_CAMERA",
  "imageUrl": "https://firebasestorage.googleapis.com/...",
  "camera": "back",
  "status": "ok",
  "deviceModel": "Pixel 7",
  "androidVer": "14",
  "responseTime": <server timestamp>,
  "sentFrom": "remotecam-android"
}
```

---

## Supported Commands

| Command | Payload | What happens |
|---------|---------|--------------|
| `CAPTURE_CAMERA` | `{"camera": "back"}` or `{"camera": "front"}` | Takes photo, uploads to Storage, returns URL |
| `PING` | `{}` | Returns `{"status": "pong", "device": "..."}` |
| `LOG_STATUS` | `{}` | Returns device info + service state |
| Any other string | any | Returns `{"status": "acknowledged"}` |

---

## Firebase Security Rules (for production)

Replace **test mode** rules with these once you add authentication:

### Firestore Rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /commands/{doc} {
      allow read, write: if request.auth != null;
    }
  }
}
```

### Storage Rules
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /captures/{file} {
      allow read, write: if request.auth != null;
    }
  }
}
```

---

## Why It Works in the Background

Android normally kills apps to save battery. This app survives because:

1. **Foreground Service** — declared with `android:foregroundServiceType="camera"` in the manifest.
   Shows a persistent notification. Android is not allowed to kill foreground services
   except in extreme low-memory situations.

2. **Camera2 API** — used instead of CameraX because Camera2 works without a
   lifecycle owner (no Activity needed). The service runs its own `HandlerThread`
   for camera callbacks.

3. **START_STICKY** — if Android does kill the service, it automatically restarts it.

4. **BootReceiver** — if the device reboots, the service restarts automatically
   (requires "Auto-start on boot" toggle enabled in the app).

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Build fails: "google-services.json not found" | Download it from Firebase Console and place in `app/` folder |
| Service stops on some phones (Xiaomi, Huawei, Samsung) | Go to battery settings → find RemoteCam → set to "No restrictions" / "Don't optimize" |
| Camera error code 3 | Another app is using the camera — close camera apps first |
| Photos not uploading | Check Firebase Storage rules are in test mode or auth is set up |
| Commands not received | Check the collection path matches in both the app and dashboard |

---

## Battery & Privacy Notes

- The foreground notification tells the user the service is running — it cannot be hidden
- The service uses negligible battery when idle (just a Firestore socket connection)
- Camera only activates when a `CAPTURE_CAMERA` command is received
- To stop everything: tap **■ STOP** in the app, or pull down the notification and tap **Stop**
